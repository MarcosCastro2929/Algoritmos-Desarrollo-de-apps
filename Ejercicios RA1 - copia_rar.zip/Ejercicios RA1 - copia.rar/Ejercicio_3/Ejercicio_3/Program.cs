﻿using System;

class Program
{
    static void Main(string[] args)
    {
        {
            int numeroVeces;
            double valor = 0;
            double acumuladoSuma = 0;
            double acumuladoResta = 0;
            double acumuladoMultiplicacion = 1;
            double acumuladoDivision = 1;
            Console.WriteLine("Cuantos numeros deseas operar?");
            numeroVeces = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i <= numeroVeces; i++)
            {
                Console.WriteLine("Ingresa un valor" + i);
                valor = Convert.ToDouble(Console.ReadLine());

              


                acumuladoSuma = acumuladoSuma + valor;

                




                if (i == 1)
                {
                    acumuladoResta = valor;
                }
                else
                {
                    acumuladoResta = acumuladoResta - valor;
                }

                




                acumuladoMultiplicacion = acumuladoMultiplicacion * valor;

                




                if (i == 1)
                {
                    acumuladoDivision = valor;
                }
                else
                {
                    if (valor != 0)
                    {
                        acumuladoDivision = acumuladoDivision / valor;
                    }
                    else
                    {
                        Console.WriteLine("Error: No se puede dividir entre cero");
                        return;
                    }
                }
            }

            Console.WriteLine("El resultado de la suma es... " + acumuladoSuma);
            Console.WriteLine("El resultado de la resta es... " + acumuladoResta);
            Console.WriteLine("El resultado de la multiplicacion es... " + acumuladoMultiplicacion);
            Console.WriteLine("El resultado de la division es... " + acumuladoDivision);
            Console.ReadLine();
        }
    }
}